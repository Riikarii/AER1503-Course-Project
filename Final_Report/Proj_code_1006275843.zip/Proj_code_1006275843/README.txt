This README files contains instructions on how to run the OpenMDAO optimization code for Ritik's AER1503 Course Project.

Please ensure that every file here is kept in the same directory.

The "new_model.py" file runs the full optimization code, which loops through three initial guesses for the two design variables and produces two plots. Each of the other Python files contains Explicit Components, the workings of which are described in the final project report. The "optimization_convergence.sqlite" file is used for recording the various optimization results across each trial for plotting purposes.

Specific descriptions for what blocks of code do in each file are included as in-text comments within.